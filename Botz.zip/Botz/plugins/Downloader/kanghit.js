// Klo mau pake, pake aja ini bkn enc cma terser aja

import axios from"axios";async function apivisit(){axios.get("https://status.pnggilajacn.my.id"),axios.get("https://status.pnggilajacn.my.id")}export{apivisit};